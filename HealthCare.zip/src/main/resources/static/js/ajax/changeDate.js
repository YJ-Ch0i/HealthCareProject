
//PT 날짜 선택
$("#ptRecord").change(function(){
	if(this.value == -1){
		$("#trReport").hide();
		$("#trRepSelect").show();
		return false;
	}
	else{
		$("#trRepSelect").hide();
		$("#trReport").show();
	}
	
	$.ajax({
	 type: "post",
	 url: "/member/ptDateDetail",
	 dataType:"json",
	 data:{psTrainDetailSeq : this.value},
	 success: function(result){
		 
		 $("#ptRemark").text(result.remark);
		 $("#trainer").text('작성자 : ' + result.trainer + ' 트레이너');
		 $("#date").text('작성일 : ' + result.markDate);
		 
		 var totalCount = 0;
		 var arr = new Array();
		 var nameArr = new Array();
		 
		 var arrData = JSON.parse(result.trainData);

		 //콤보차트를 위한 Object
		 var pieDataArr = new Array();
		 for(var i=0; i<arrData.length; i++){		
		 	var pieDataObj = new Object();
		 	var dataArr = new Array();
		 	nameArr.push(arrData[i].exerName);
		 	
		 	var obj = new Object();
		 	obj.type='column';
		 	obj.name=arrData[i].exerName;
		 	dataArr.push(Number(arrData[i].exerCount));
		 	obj.data=dataArr;
		 	
		 	pieDataObj.name=arrData[i].exerName;
		 	pieDataObj.y = Number(arrData[i].exerCount);
		 	pieDataObj.color = Highcharts.getOptions().colors[i];
		 	pieDataArr.push(pieDataObj);
		 	
		 	totalCount += Number(arrData[i].exerCount);
		 	
		 	arr.push(obj);
		 }

		 var pieObj = new Object();
		 pieObj.type='pie';
		 pieObj.name='운동량';
		 pieObj.data=pieDataArr;
		 pieObj.center = [100, 80];
		 pieObj.size = 100;
		 pieObj.showInLegend = false;

		 arr.push(pieObj);

		 console.log(nameArr);
		 console.log(arr);
		 
		 //버블차트를 위한 Object
		 var bubbleArr = new Array();
		 for(var i=0; i<arrData.length; i++){
		 	var addArr = new Array();
		 	var exerObj = new Object();
		 	exerObj.name = arrData[i].exerName;
		 	exerObj.value= Number(arrData[i].exerCount);
		 	addArr.push(exerObj);
		 	var obj = new Object();
		 	obj.name = exerObj.name;
		 	obj.data = addArr;
		 	
		 	bubbleArr.push(obj);
		 }

		 console.log(bubbleArr);
		 
		 
		 //콤보차트
		 Highcharts.chart('trainingReportCombo', {
		     title: {
		         text: result.trainDate + ' 운동량 비율'
		     }, 
		     xAxis: {
		         categories: ['']
		     },
		     credits: {
			        enabled: false
		     },
		     series: arr
		 });
		 
		 //버블차트
		 Highcharts.chart('trainingReportBubble', {
			    chart: {
			        type: 'packedbubble',
			        height: '50%'
			    },
			    title: {
			        text: result.trainDate + ' 운동량',
			    },
			    tooltip: {
			        useHTML: true,
			        pointFormat: '<b>{point.name}:</b> {point.value}분/회'
			    },
			    plotOptions: {
			        packedbubble: {
			            minSize: '30%',
			            maxSize: '100%',
			            zMin: 0,
			            zMax: 1000,
			            layoutAlgorithm: {
			                splitSeries: false,
			                gravitationalConstant: 0.02
			            },
			            dataLabels: {
			                enabled: true,
			                format: '<b>{point.name}:</b> {point.value}회',
			                filter: {
			                    property: 'y',
			                    operator: '>',
			                    value: 10
			                },
			                style: {
			                    color: 'black',
			                    textOutline: 'none',
			                    fontWeight: 'normal'
			                }
			            }
			        }
			    },
			    credits: {
			        enabled: false
			    },
			    series: bubbleArr
			});

	},
	error: function (request,status,error) {
		   alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		   console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
	}
//		error: function (jqXHR, textStatus, errorThrown) {
//			   alert("오류가 발생하였습니다.");
//		}
 });
})


//인바디 날짜 선택
$("#indobyRecord").change(function(){
	if(this.value == -1){
		$("#inbodyReport").hide();
		$("#inbodyRepSelect").show();
		return false;
	}
	else{
		$("#inbodyRepSelect").hide();
		$("#inbodyReport").show();
	}
	
	$.ajax({
	 type: "post",
	 url: "/member/inbodyDateDetail",
	 dataType:"json",
	 data:{inBodySeq : this.value},
	 success: function(result){
		 console.log(result.inbodyReport);
		 console.log(result.trainer);
		 console.log(result.measuredDate);
		 console.log(result.markDate);
		 
		 var json = JSON.parse(result.inbodyReport);
		 
		 //인바디 근육량 지방량 파이차트
		 Highcharts.chart('inbodyMusclePie', {
			    chart: {
			        plotBackgroundColor: null,
			        plotBorderWidth: null,
			        plotShadow: false,
			        type: 'pie'
			    },
			    title: {
			        text: '근육량 및 지방량'
			    },
			    tooltip: {
			        pointFormat: '{series.name}: <b>{point.y:.1f}</b>'
			    },
			    plotOptions: {
			        pie: {
			            allowPointSelect: true,
			            cursor: 'pointer',
			            dataLabels: {
			                enabled: true,
			                format: '<b>{point.name}</b>: {point.y:.1f}'
			            }
			        }
			    },
			    credits: {
			        enabled: false
			    },
			    series: [{
			    	name:'근육량 및 지방량',
			        colorByPoint: true,
			        data: [{
			            name: '근육량',
			            y: json.muscleMass,
			            color:Highcharts.getOptions().colors[5],
			            sliced: true,
			            selected: true
			        }, {
			            name: '지방량',
			            color:Highcharts.getOptions().colors[6],
			            y: json.fatMass
			        }]
			    }]
			});
		
		 //인바디 몸무게 파이차트
		 Highcharts.chart('inbodyWeightPie', {
		     chart: {
		         plotBackgroundColor: null,
		         plotBorderWidth: null,
		         plotShadow: false,
		         type: 'pie'
		     },
		     title: {
		         text: '키 및 몸무게'
		     },
		     tooltip: {
		         pointFormat: '{series.name}: <b>{point.y:.1f}</b>'
		     },
		     plotOptions: {
		         pie: {
		             allowPointSelect: true,
		             cursor: 'pointer',
		             dataLabels: {
		                 enabled: true,
		                 format: '<b>{point.name}</b>: {point.y:.1f}'
		             }
		         }
		     },
		     credits: {
			        enabled: false
		     },
		     series: [{
		     	name:'근육량 및 지방량',
		         colorByPoint: true,
		         data: [{
		             name: '키',
		             y: json.height,
		             color:Highcharts.getOptions().colors[3],
		             sliced: true
		         }, {
		             name: '몸무게',
		             y: json.weight,
		             color:Highcharts.getOptions().colors[4],
		             selected: true
		         }]
		     }]
		 });
		 
		 //인바디 BMI 및 기초대사량 지수 파이차트
		 Highcharts.chart('inbodyBmiMetabolic', {
			    chart: {
			        plotBackgroundColor: null,
			        plotBorderWidth: null,
			        plotShadow: false,
			        type: 'pie'
			    },
			    title: {
			        text: 'BMI지수 및 기초대사량'
			    },
			    tooltip: {
			        pointFormat: '{series.name}: <b>{point.y:.1f}</b>'
			    },
			    plotOptions: {
			        pie: {
			            allowPointSelect: true,
			            cursor: 'pointer',
			            dataLabels: {
			                enabled: true,
			                format: '<b>{point.name}</b>: {point.y:.1f}'
			            }
			        }
			    },
			    credits: {
			        enabled: false
			    },
			    series: [{
			    	name:'근육량 및 지방량',
			        colorByPoint: true,
			        data: [{
			            name: '기초대사량',
			            y: json.bMetabolicRate,
			            color:Highcharts.getOptions().colors[0],
			            sliced: true
			        }, {
			            name: 'BMI',
			            y: json.bmi,
			            color:Highcharts.getOptions().colors[8],
			            selected: true
			        }]
			    }]
			});
		 
		 
		 
		 
	},
	error: function (request,status,error) {
		   alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		   console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
	}
//		error: function (jqXHR, textStatus, errorThrown) {
//			   alert("오류가 발생하였습니다.");
//		}
 });
})




