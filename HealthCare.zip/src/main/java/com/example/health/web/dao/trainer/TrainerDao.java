package com.example.health.web.dao.trainer;

import java.util.List;

import com.example.health.web.dto.pt.InbodyDto;
import com.example.health.web.dto.pt.PTdetailDto;
import com.example.health.web.dto.pt.PTpriceDto;
import com.example.health.web.dto.pt.PersonalTrainingDto;
import com.example.health.web.dto.user.MemberDto;
import com.example.health.web.dto.user.TrainerDto;

public interface TrainerDao {

	/**
	 * id값으로 트레이너 객체 가져오기
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public TrainerDto getTrainer(String id) throws Exception;
	
	public MemberDto getMember(int memberSeq) throws Exception;
	
	public int registerMember(MemberDto dto) throws Exception;
	
	public int registerTrainer(TrainerDto dto) throws Exception;
	
	public List<TrainerDto> getTrainerList() throws Exception;
	
	public List<MemberDto> getMemberListForSearch(int userSeq, String memberName) throws Exception;
	
	public List<MemberDto> getMemberListForAdmin(String memberName) throws Exception;
	
	public List<MemberDto> getMemberList(TrainerDto dto) throws Exception;
	
	public List<MemberDto> getAllMemberList() throws Exception;
	
	public List<PersonalTrainingDto> getPTList() throws Exception;
	
	public int registerMemberInbodyInfo(InbodyDto dto) throws Exception;
	
	public int registerMemberPtInfo(PTdetailDto dto) throws Exception;
	
	public PTdetailDto getPtDetail(int seq) throws Exception;
	
	public InbodyDto getInbody(int seq) throws Exception;
	
	public List<PTpriceDto> getPtPrices() throws Exception;
	
	public boolean registerPtPrograms(PersonalTrainingDto dto) throws Exception;
	
}
