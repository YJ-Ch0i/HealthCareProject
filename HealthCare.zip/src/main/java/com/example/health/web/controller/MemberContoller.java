package com.example.health.web.controller;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.health.common.CommonUtil;
import com.example.health.web.dto.pt.ExerciseType;
import com.example.health.web.dto.pt.InbodyDto;
import com.example.health.web.dto.pt.PTdetailDto;
import com.example.health.web.dto.pt.PersonalTrainingDto;
import com.example.health.web.dto.user.MemberDto;
import com.example.health.web.dto.user.TrainerDto;
import com.example.health.web.service.member.MemberServiceImpl;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

@Controller
public class MemberContoller {
	
	@Autowired
	private MemberServiceImpl memService;
	
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	String date = format.format(System.currentTimeMillis());
	Gson gson;
	
	@RequestMapping(value="/trainer/memberDetailBoard", method={RequestMethod.GET, RequestMethod.POST})
	public String moveInfoPage(Model model, HttpServletRequest request) throws Exception {
		MemberDto member = memService.getMember(CommonUtil.strToInt(request.getParameter("memberValue")));
		List<PTdetailDto> membersRecords = memService.getMembersRecord(member);
		PersonalTrainingDto ptDto = memService.getMembersPt(member);
		HttpSession session = request.getSession();
		TrainerDto trainer = (TrainerDto)session.getAttribute("loginInfo");
		
		model.addAttribute("ptDesc", ptDto);
		model.addAttribute("member", member);
		model.addAttribute("trainer", trainer);
		model.addAttribute("records", membersRecords);	
		return "user/trainer/trMemberInfo";
	}
	
	/**
	 * PT게시판 ajax 로딩용 메소드
	 * @return
	 */
	@RequestMapping(value="/trainer/memberPtBoard", method= {RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody String trainerMembersInfoPT(HttpServletRequest request) throws Exception {
		MemberDto member = memService.getMember(CommonUtil.strToInt(request.getParameter("memberSeq")));
		List<PTdetailDto> membersRecords = memService.getMembersRecord(member);
		gson = new Gson();
		String json = gson.toJson(membersRecords);
		return json;
	}
	
	/**
	 * 인바디 게시판 ajax 로딩용 메소드
	 * @return
	 */
	@RequestMapping(value="/trainer/memberInbodyBoard", method= {RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody String trainerMembersInfoInbody(HttpServletRequest request) throws Exception {
		MemberDto member = memService.getMember(CommonUtil.strToInt(request.getParameter("memberSeq")));
		List<InbodyDto> membersRecords = memService.getMembersInbody(member);
		
		gson = new Gson();
		String json = gson.toJson(membersRecords);
		return json;
	}
	
	/**
	 * pt게시판 작성 컨트롤러 메소드
	 * @return
	 */
	@RequestMapping(value="/trainer/writePtInfo", method=RequestMethod.POST)
	public String registPtInformation(HttpServletRequest request, Model model) throws Exception {
		MemberDto member = memService.getMember(CommonUtil.strToInt(request.getParameter("memberS")));
		
		model.addAttribute("member", member);
		model.addAttribute("nowDate", date);
		return "user/trainer/boardWrite/trMemberPtInfoWrite";
	}
	
	/**
	 * inbody게시판 작성 컨트롤러 메소드
	 * @return
	 */
	@RequestMapping(value="/trainer/writeInbodyInfo", method=RequestMethod.POST)
	public String registInbodyInformation(HttpServletRequest request, Model model) throws Exception {
		MemberDto member = memService.getMember(CommonUtil.strToInt(request.getParameter("memberS")));
		model.addAttribute("member", member);
		model.addAttribute("nowDate", date);
		return "user/trainer/boardWrite/trMemberInbodyInfoWrite";
	}
	
	@RequestMapping(value="/member/Login", method= {RequestMethod.POST})
	public @ResponseBody String loginMember(MemberDto dto, HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();
		JsonObject obj = new JsonObject();
		String json = "";
		MemberDto member = memService.getMemberInfo(dto);
		
		if(memService.isMemberRegisterd(member)) {
			session.setAttribute("memberInfo", member);
			obj.addProperty("result", "/member/main");
			json = new Gson().toJson(obj);
		}
		else {
			obj.addProperty("result", false);
			json = new Gson().toJson(obj);
		}
		return json;
	}
	
	@RequestMapping(value="/member/main")
	public String memberMain(HttpServletRequest request, Model model) throws Exception {
		HttpSession session = request.getSession();
		MemberDto memberSession = (MemberDto) session.getAttribute("memberInfo");
		List<PTdetailDto> ptRecordList = memService.getMembersRecord(memberSession);
		List<InbodyDto> inbodyRecordList = memService.getMembersInbody(memberSession);
		
		model.addAttribute("inbodyRecords", inbodyRecordList);
		model.addAttribute("ptRecords", ptRecordList);
		session.setAttribute("memberInfo", memberSession);
		return "user/member/memberMain";
	}
	
	@RequestMapping(value="/member/ptDateDetail", method=RequestMethod.POST)
	public @ResponseBody String searchMemberPtDateDetail(HttpServletRequest request, PTdetailDto dto) throws Exception {
		
		Map<String, Object> map = memService.getMemberPtRecord(dto);
		
		PTdetailDto ptReport = (PTdetailDto) map.get("report");
		List<ExerciseType> list = (List<ExerciseType>) map.get("list");
		JsonArray arr = (JsonArray) map.get("json");
		
		TrainerDto trainer = memService.getMyTrainer(ptReport.getUserSeq());
		
		Gson gson = new Gson();
		
		String report = gson.toJson(arr);		
		
		JsonObject obj = new JsonObject();
		obj.addProperty("trainData", report);
		obj.addProperty("remark", ptReport.getRemark());
		obj.addProperty("trainer", trainer.getTrainName());
		obj.addProperty("trainDate", ptReport.getPsTrainDate().toString());
		obj.addProperty("markDate", ptReport.getLastDate().toString());
		String json = gson.toJson(obj);
		
		return json;
	}
	
	@RequestMapping(value="/member/inbodyDateDetail", method=RequestMethod.POST)
	public @ResponseBody String searchMemberInbodyDateDetail(HttpServletRequest request, InbodyDto dto) throws Exception {
		
		Map<String, Object> map = memService.getMemberInbodyRecord(dto);
		InbodyDto inbody = (InbodyDto) map.get("inbody");
		String report = (String) map.get("json");
		TrainerDto trainer = memService.getMyTrainer(inbody.getUserSeq());
		
		JsonObject obj = new JsonObject();
		obj.addProperty("inbodyReport", report);
		obj.addProperty("trainer", trainer.getTrainName());
		obj.addProperty("measuredDate", inbody.getInBodyDate().toString());
		obj.addProperty("markDate", inbody.getLastDate().toString());
		
		String json = new Gson().toJson(obj);
		return json;
		
	}

}
