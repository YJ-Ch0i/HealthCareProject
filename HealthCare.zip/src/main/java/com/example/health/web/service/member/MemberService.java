package com.example.health.web.service.member;

import com.example.health.web.dto.user.MemberDto;

public interface MemberService {

	public MemberDto getMember(int memberSeq) throws Exception;
}
