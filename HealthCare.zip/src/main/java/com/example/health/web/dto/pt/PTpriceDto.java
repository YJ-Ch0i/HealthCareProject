package com.example.health.web.dto.pt;

/**
 * pt 가격정보 테이블 
 * @author yeong
 *
 */
public class PTpriceDto {

	private int psTrainPriceSeq;
	private int psTrainPrice;
	
	public int getPsTrainPriceSeq() {
		return psTrainPriceSeq;
	}
	public void setPsTrainPriceSeq(int psTrainPriceSeq) {
		this.psTrainPriceSeq = psTrainPriceSeq;
	}
	public int getPsTrainPrice() {
		return psTrainPrice;
	}
	public void setPsTrainPrice(int psTrainPrice) {
		this.psTrainPrice = psTrainPrice;
	}
}
