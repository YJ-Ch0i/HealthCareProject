function addRow(){
	var count = document.getElementById("count").value;
	var addTable = document.getElementById("addTable");
	var row = addTable.insertRow();
	row.onmouseover=function(){
		addTable.clickedRowIndex=this.rowIndex;
	}
	var cell = row.insertCell();
	
	var form = '<input type="text" id="exerName' + count + '" class="input-md form-control" style="width:200px" placeholder="운동" required>';
	cell.innerHTML = form;
	
	cell = row.insertCell();
	form = '<input type="number" id="exerCount' + count + '" class="input-md form-control" style="width:100px" placeholder="실시한 횟수" required>';
	cell.innerHTML = form;
	
	cell = row.insertCell();
	form = '&nbsp; <input type="button" class="btn btn-mod btn-small" value="삭제" onClick="remove()" style="cursor:hand">';
	cell.innerHTML = form;
	count++;
	document.getElementById("count").value = count;
}

function remove(){
	addTable.deleteRow(addTable.clickedRowIndex);
	var count = document.getElementById("count").value;
	count--;
	document.getElementById("count").value = count;
}

$("#ptWriteBtn").click(function(){
	
	var psTrainDate = $("#psTrainDate").val();
	var memSeq = $("#memberSeq").val();
	var lastDate = $("#lastDate").val();
	var changeUser = $("#changeUser").val();
	var remark = $("#remark").val();
	var count = $("#count").val();	//운동 갯수
	
	var trainData = new Array();
	for(var i=0; i<count; i++){
		var train = new Object();
		train.exerName = $("#" + "exerName" + i).val();
		train.exerCount = $("#" + "exerCount" + i).val();
		trainData.push(train);
	}	
	var json = JSON.stringify(trainData);
	
	$.ajax({
		 type: "post",
		 url: "/trainer/memberPtRegister",
		 dataType:"json",
		 data:{psTrainDate : psTrainDate,
			 memberSeq : memSeq,			 
			 trainData : json,
			 remark : remark,
			 userSeq : changeUser,
			 lastDate : lastDate},
		 success: function(result){
			 console.log(result.result);
			 
			 if(result.result == false){
				 alert("등록에 실패했습니다. 다시 확인하여 주세요");
			 }
			 else{
				 alert("성공적으로 등록 되었습니다!");
				 location.href=result.result;
			 }
			 
		},
		error: function (request,status,error) {
			   alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
			   console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		}
//		error: function (jqXHR, textStatus, errorThrown) {
//			   alert("오류가 발생하였습니다.");
//		}
	 });
});