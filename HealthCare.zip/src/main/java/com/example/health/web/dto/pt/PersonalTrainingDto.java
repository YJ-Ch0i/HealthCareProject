package com.example.health.web.dto.pt;

import java.sql.Date;

/**
 * PT정보 테이블
 * @author yeong
 *
 */
public class PersonalTrainingDto {

	private int psTrainSeq;
	private String psTrainName;
	private int psTrainCount;
	private int psTrainPriceSeq;
	private int lastUserSeq;
	private Date lastDate;
	
	public int getPsTrainSeq() {
		return psTrainSeq;
	}
	public void setPsTrainSeq(int psTrainSeq) {
		this.psTrainSeq = psTrainSeq;
	}
	public String getPsTrainName() {
		return psTrainName;
	}
	public void setPsTrainName(String psTrainName) {
		this.psTrainName = psTrainName;
	}
	public int getPsTrainCount() {
		return psTrainCount;
	}
	public void setPsTrainCount(int psTrainCount) {
		this.psTrainCount = psTrainCount;
	}
	public int getPsTrainPriceSeq() {
		return psTrainPriceSeq;
	}
	public void setPsTrainPriceSeq(int psTrainPriceSeq) {
		this.psTrainPriceSeq = psTrainPriceSeq;
	}
	public int getLastUserSeq() {
		return lastUserSeq;
	}
	public void setLastUserSeq(int lastUserSeq) {
		this.lastUserSeq = lastUserSeq;
	}
	public Date getLastDate() {
		return lastDate;
	}
	public void setLastDate(Date lastDate) {
		this.lastDate = lastDate;
	}
}
