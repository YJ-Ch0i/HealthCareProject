var exer = $("#exercise").val();
var date = $("#regiDate").val();

console.log(exer);
var arrData = JSON.parse(exer);
console.log(arrData);

var arr = new Array();
for(var i=0; i<arrData.length; i++){
	var addArr = new Array();
	var exerObj = new Object();
	exerObj.name = arrData[i].exerName;
	exerObj.value= Number(arrData[i].exerCount);
	addArr.push(exerObj);
	var obj = new Object();
	obj.name = exerObj.name;
	obj.data = addArr;
	
	arr.push(obj);
}

console.log(arr);

Highcharts.chart('trainingReportBubble', {
    chart: {
        type: 'packedbubble',
        height: '50%'
    },
    title: {
        text: date + ' 운동량',
    },
    tooltip: {
        useHTML: true,
        pointFormat: '<b>{point.name}:</b> {point.value}회'
    },
    plotOptions: {
        packedbubble: {
            minSize: '30%',
            maxSize: '100%',
            zMin: 0,
            zMax: 1000,
            layoutAlgorithm: {
                splitSeries: false,
                gravitationalConstant: 0.02
            },
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}:</b> {point.value}회',
                filter: {
                    property: 'y',
                    operator: '>',
                    value: 10
                },
                style: {
                    color: 'black',
                    textOutline: 'none',
                    fontWeight: 'normal'
                }
            }
        }
    },
    credits: {
        enabled: false
    },
    series: arr
});
