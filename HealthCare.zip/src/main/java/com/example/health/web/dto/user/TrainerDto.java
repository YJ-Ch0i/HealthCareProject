package com.example.health.web.dto.user;

import java.sql.Date;

public class TrainerDto {
	private int userSeq;
	private String userId;
	private String userPw;
	private String trainName;
	private String trainPhone;
	private int userAuthSeq;
	private int lastUserSeq;
	private Date lastDate;
	
	public int getUserSeq() {
		return userSeq;
	}
	public void setUserSeq(int userSeq) {
		this.userSeq = userSeq;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserPw() {
		return userPw;
	}
	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainerName) {
		this.trainName = trainerName;
	}
	public String getTrainPhone() {
		return trainPhone;
	}
	public void setTrainPhone(String trainerPhone) {
		this.trainPhone = trainerPhone;
	}
	public int getUserAuthSeq() {
		return userAuthSeq;
	}
	public void setUserAuthSeq(int userAuthSeq) {
		this.userAuthSeq = userAuthSeq;
	}
	public int getLastUserSeq() {
		return lastUserSeq;
	}
	public void setLastUserSeq(int lastUserSeq) {
		this.lastUserSeq = lastUserSeq;
	}
	public Date getLastDate() {
		return lastDate;
	}
	public void setLastDate(Date lastDate) {
		this.lastDate = lastDate;
	}
}
