var json = JSON.parse($("#inbody").val());

console.log(json);

Highcharts.chart('inbodyMusclePie', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: '근육량 및 지방량'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.y:.1f}</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.y:.1f}'
            }
        }
    },
    credits: {
        enabled: false
    },
    series: [{
    	name:'근육량 및 지방량',
        colorByPoint: true,
        data: [{
            name: '근육량',
            y: json.muscleMass,
            color:Highcharts.getOptions().colors[5],
            sliced: true,
            selected: true
        }, {
            name: '지방량',
            color:Highcharts.getOptions().colors[6],
            y: json.fatMass
        }]
    }]
});