var json = JSON.parse($("#inbody").val());

console.log(json);

Highcharts.chart('inbodyWeightPie', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: '키 및 몸무게'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.y:.1f}</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.y:.1f}'
            }
        }
    },
    credits: {
        enabled: false
    },
    series: [{
    	name:'근육량 및 지방량',
        colorByPoint: true,
        data: [{
            name: '키',
            y: json.height,
            color:Highcharts.getOptions().colors[3],
            sliced: true
        }, {
            name: '몸무게',
            y: json.weight,
            color:Highcharts.getOptions().colors[4],
            selected: true
        }]
    }]
});