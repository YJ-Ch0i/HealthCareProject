
//회원등록 ajax
$("#registerBtn").click(function(){
	var memName = $("#memberName").val();
	var memPhone = $("#memberPhone").val();
	var memAge = $("#memberAge").val();
	var memGender = $("#memberGender option:selected").val();
	var enrollFr = $("#enrollFr").val();
	var enrollTo = $("#enrollTo").val();
	var isTraining = $("#isTraining").val();
	var ptOption = $("#ptList").val();
	var trName = $("#trainerList").val();
	var regiDate = $("#lastDate").val();
	var changeUser = $("#changeUser").val();
	
	//빈값체크
	if(memName == ""){
		alert("이름을 입력 해 주세요");
		$("#memberName").focus();
		return false;
	}
	if(memAge == ""){
		alert("나이를 입력 해 주세요");
		$("#memberAge").focus();
		return false;
	}
	if(memGender == "" || memGender == -1){
		alert("성별을 선택 해 주세요");
		$("#memberGender").focus();
		return false;
	}
	if(memPhone == ""){
		alert("휴대폰 번호를 입력 해 주세요");
		$("#memberPhone").focus();
		return false;
	}
	if(enrollFr == ""){
		alert("등록일을 입력 해 주세요");
		$("#enrollFr").focus();
		return false;
	}
	if(enrollTo == ""){
		alert("만료일을 입력 해 주세요");
		$("#enrollTo").focus();
		return false;
	}
	if(isTraining == "" || isTraining == -1){
		alert("PT적용 여부를 선택 해 주세요.");
		$("#isTraining").focus();
		return false;
	}
	
	if(isTraining == 1){
		isTraining = true;
	}
	else if(isTraining == 2 || isTraining == -1){
		isTraining = false;
		ptOption = 0;
		trName = 0;
	}
	
	
	console.log("ajax 진입");

	$.ajax({
	 type: "post",
	 url: "/trainer/memberRegister",
	 dataType:"json",
	 data:{memberName : memName,
		 memberPhone : memPhone,
		 memberAge : memAge,
		 memberGender : memGender,
		 enrollFr : enrollFr,
		 enrollTo : enrollTo,
		 psTrainSeq: ptOption,
		 psTrainCheck : isTraining,
		 userSeq : trName,
		 lastDate : regiDate,
		 lastUserSeq : changeUser},
	 success: function(result){
		 console.log(result.result);
		 if(result.result == false){
			 alert("등록에 실패했습니다. 다시 확인하여 주세요");
		 }
		 else{
			 alert("성공적으로 등록 되었습니다!");
			 location.href=result.result;
		 }
	},
	error: function (request,status,error) {
		   alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		   console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
	}
//	error: function (jqXHR, textStatus, errorThrown) {
//		   alert("오류가 발생하였습니다.");
//	}
 });
});

//트레이너 등록 ajax
$("#trRegiBtn").click(function(){

	var trId = $("#trId").val();
	var trPass = $("#trPass").val();
	var rePass = $("#rePass").val();
	var trName = $("#trName").val();
	var trPhone = $("#trPhone").val();
	var regiDate = $("#lastDate").val();
	var changeUser = parseInt($("#changeUser").val());
	
	//빈값체크
	if(trId == ""){
		alert("사용하실 ID를 입력 해 주세요");
		$("#trId").focus();
		return false;
	}
	if(trPass == ""){
		alert("사용하실 비밀번호를 입력 해 주세요");
		$("#trPass").focus();
		return false;
	}
	if(rePass == ""){
		alert("비밀번호를 확인 해 주세요.");
		$("#rePass").focus();
		return false;
	}
	if(trName == ""){
		alert("이름을 입력 해 주세요.");
		$("#trName").focus();
		return false;
	}
	if(trPhone == ""){
		alert("휴대폰 번호를 입력 해 주세요");
		$("#trPhone").focus();
		return false;
	}
	
	console.log("ajax 진입");

	$.ajax({
	 type: "post",
	 url: "/trainer/trainerRegist",
	 dataType:"json",
	 data:{userId : trId,
		 userPw : trPass,
		 trainName : trName,
		 trainPhone : trPhone,
		 userAuthSeq : 2,
		 lastUserSeq : changeUser,
		 lastDate : regiDate},
	 success: function(result){
		 console.log(result.result);
		 if(result.result == false){
			 alert("등록에 실패했습니다. 다시 확인하여 주세요");
		 }
		 else{
			 alert("성공적으로 등록 되었습니다!");
			 location.href=result.result;
		 }
	},
	error: function (request,status,error) {
		   alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		   console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
	}
//	error: function (jqXHR, textStatus, errorThrown) {
//		   alert("오류가 발생하였습니다.");
//	}
 });
});


//PT프로그램 등록 ajax
$("#ptRegisterBtn").click(function(){

	var ptName = $("#psTrainName").val();
	var ptCount = $("#psTrainCount").val();
	var ptPrice = $("#psTrainPriceSeq").val();
	var regiDate = $("#lastDate").val();
	var changeUser = parseInt($("#changeUser").val());
	
	//빈값체크
	if(ptName == ""){
		alert("프로그램 이름을 입력 해 주세요");
		$("#psTrainName").focus();
		return false;
	}
	if(ptCount == ""){
		alert("횟수를 작성 해 주세요");
		$("#psTrainCount").focus();
		return false;
	}
	if(ptPrice == ""){
		alert("가격을 선택 해 주세요");
		$("#psTrainPriceSeq").focus();
		return false;
	}
	
	console.log("ajax 진입");

	$.ajax({
	 type: "post",
	 url: "/trainer/ptProgramRegister",
	 dataType:"json",
	 data:{psTrainName : ptName,
		 psTrainCount : ptCount,
		 psTrainPriceSeq : ptPrice,		 
		 lastUserSeq : changeUser,
		 lastDate : regiDate},
	 success: function(result){
		 console.log(result.result);
		 if(result.result == false){
			 alert("등록에 실패했습니다. 다시 확인하여 주세요");
		 }
		 else{
			 alert("성공적으로 등록 되었습니다!");
			 location.href=result.result;
		 }
	},
	error: function (request,status,error) {
		   alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		   console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
	}
//	error: function (jqXHR, textStatus, errorThrown) {
//		   alert("오류가 발생하였습니다.");
//	}
 });
});



//회원 인바디 기록 ajax
$("#inbodyWriteBtn").click(function(){

	var inbodyDate = $("#inbodyDate").val();
	var weight = $("#weight").val();
	var height = $("#height").val();
	var muscleMass = $("#muscleMass").val();
	var FatMass = $("#FatMass").val();
	var bmi = $("#bmi").val();
	var metabolic = $("#metabolic").val();
	var changeUser = $("#changeUser").val();
	var regiDate = $("#lastDate").val();
	var memberSeq = $("#memberSeq").val();	
	
	//빈값 체크
	if(weight == ""){
		alert("몸무게를 입력 해 주세요");
		$("#weight").focus();
		return false;
	}
	if(height == ""){
		alert("키를 입력 해 주세요.");
		$("#height").focus();
		return false;
	}
	if(muscleMass == ""){
		alert("근육량을 입력 해 주세요.");
		$("#muscleMass").focus();
		return false;
	}
	if(FatMass == ""){
		alert("지방량을 입력 해 주세요");
		$("#FatMass").focus();
		return false;
	}
	if(bmi == ""){
		alert("bmi지수를 입력 해 주세요");
		$("#bmi").focus();
		return false;
	}
	if(metabolic == ""){
		alert("기초대사량을 입력 해 주세요");
		$("#metabolic").focus();
		return false;
	}
	
	console.log("ajax 진입");

	$.ajax({
	 type: "post",
	 url: "/trainer/memberInbodyRegister",
	 dataType:"json",
	 data:{memberSeq : memberSeq,
		 weight : weight,
		 height : height,
		 muscleMass : muscleMass,
		 FatMass : FatMass,
		 bmi : bmi,
		 bMetabolicRate : metabolic,
		 userSeq : changeUser,
		 inBodyDate : inbodyDate,
		 lastDate : regiDate},
	 success: function(result){
		 console.log(result.result);
		 
		 if(result.result == false){
			 alert("등록에 실패했습니다. 다시 확인하여 주세요");
		 }
		 else{
			 alert("성공적으로 등록 되었습니다!");
			 location.href=result.result;
		 }
		 
	},
	error: function (request,status,error) {
		   alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		   console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
	}
//	error: function (jqXHR, textStatus, errorThrown) {
//		   alert("오류가 발생하였습니다.");
//	}
 });
});
