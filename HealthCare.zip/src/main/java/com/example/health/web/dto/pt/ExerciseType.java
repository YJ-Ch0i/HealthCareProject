package com.example.health.web.dto.pt;

public class ExerciseType {

	private String exerName;
	private String exerCount;
	
	public String getExerName() {
		return exerName;
	}
	public void setExerName(String exerName) {
		this.exerName = exerName;
	}
	public String getExerCount() {
		return exerCount;
	}
	public void setExerCount(String exerCount) {
		this.exerCount = exerCount;
	}
}
