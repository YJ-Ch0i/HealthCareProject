package com.example.health.web.dto.user;

public class TrainerLoginDto {

	private String adId;
	private String adPass;
	
	public String getAdId() {
		return adId;
	}
	public void setAdId(String adId) {
		this.adId = adId;
	}
	public String getAdPass() {
		return adPass;
	}
	public void setAdPass(String adPass) {
		this.adPass = adPass;
	}
}
