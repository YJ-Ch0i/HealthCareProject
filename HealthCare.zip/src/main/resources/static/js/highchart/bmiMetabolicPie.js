var json = JSON.parse($("#inbody").val());

console.log(json);

Highcharts.chart('inbodyBmiMetabolic', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'BMI지수 및 기초대사량'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.y:.1f}</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.y:.1f}'
            }
        }
    },
    credits: {
        enabled: false
    },
    series: [{
    	name:'근육량 및 지방량',
        colorByPoint: true,
        data: [{
            name: '기초대사량',
            y: json.bMetabolicRate,
            color:Highcharts.getOptions().colors[0],
            sliced: true
        }, {
            name: 'BMI',
            y: json.bmi,
            color:Highcharts.getOptions().colors[8],
            selected: true
        }]
    }]
});