var exer = $("#exercise").val();
var date = $("#regiDate").val();

console.log(exer);
var arrData = JSON.parse(exer);
console.log(arrData);

var totalCount = 0;
var arr = new Array();
var nameArr = new Array();

var pieDataArr = new Array();
for(var i=0; i<arrData.length; i++){		
	var pieDataObj = new Object();
	var dataArr = new Array();
	nameArr.push(arrData[i].exerName);
	
	var obj = new Object();
	obj.type='column';
	obj.name=arrData[i].exerName;
	dataArr.push(Number(arrData[i].exerCount));
	obj.data=dataArr;
	
	pieDataObj.name=arrData[i].exerName;
	pieDataObj.y = Number(arrData[i].exerCount);
	pieDataObj.color = Highcharts.getOptions().colors[i];
	pieDataArr.push(pieDataObj);
	
	totalCount += Number(arrData[i].exerCount);
	
	arr.push(obj);
}

var pieObj = new Object();
pieObj.type='pie';
pieObj.name='운동량';
pieObj.data=pieDataArr;
pieObj.center = [100, 80];
pieObj.size = 100;
pieObj.showInLegend = false;

arr.push(pieObj);

console.log(nameArr);
console.log(arr);

Highcharts.chart('trainingReportCombo', {
    title: {
        text: date + ' 운동량 비율 보기'
    }, 
    xAxis: {
        categories: ['']
    },
    credits: {
        enabled: false
    },
    series: arr
});
