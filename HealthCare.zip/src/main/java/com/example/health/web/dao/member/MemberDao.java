package com.example.health.web.dao.member;

import java.util.List;

import com.example.health.web.dto.pt.InbodyDto;
import com.example.health.web.dto.pt.PTdetailDto;
import com.example.health.web.dto.pt.PersonalTrainingDto;
import com.example.health.web.dto.user.MemberDto;
import com.example.health.web.dto.user.TrainerDto;

public interface MemberDao {

	public MemberDto getMember(int memberSeq) throws Exception;
	public List<PTdetailDto> getMembersRecord(MemberDto dto) throws Exception;
	public PersonalTrainingDto getMembersPt(MemberDto dto) throws Exception;
	public List<InbodyDto> getMembersInbody(MemberDto dto) throws Exception;
	public MemberDto getMemberInfo(MemberDto dto) throws Exception;
	
	public TrainerDto getTrainer(int userSeq) throws Exception;
	public PTdetailDto getMemberPtRecord(PTdetailDto dto) throws Exception;
	public InbodyDto getMemberInbodyRecord(InbodyDto dto) throws Exception;
}
