
//pt태그 게시글 보기
$("#ptTag").click(function(){
	
	var memberSeq = $("#memberSeq").val();
	
	$.ajax({
		type:"post",
		url:"/trainer/memberPtBoard",
		dataType:"json",
		data:{memberSeq : memberSeq},
		success: function(result){			
			var trTag = '';
			$("#inbodyAndPtTable").empty();
			
			$.each(result, function(i){
				trTag += '<tr onClick=location.href="/trainer/trainingReport?seq=' + result[i].psTrainDetailSeq + '" style="cursor:pointer;"><td>' + result[i].psTrainDetailSeq + '</td>';
				trTag += '<td>' + result[i].psTrainDate + " PT기록" + '</td>';
				trTag += '<td>' + result[i].lastDate+ '</td></tr>';
			});
			$("#inbodyAndPtTable").append(trTag);
			
		},
		error: function (request,status,error) {
			   alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
			   console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		}
//		error: function (jqXHR, textStatus, errorThrown) {
//			   alert("오류가 발생하였습니다.");
//		}
	 });
});

//inbody 태그 게시글보기
$("#inbodyTag").click(function(){
	
	var memberSeq = $("#memberSeq").val();
	
	$.ajax({
		type:"post",
		url:"/trainer/memberInbodyBoard",
		dataType:"json",
		data:{memberSeq : memberSeq},
		success: function(result){
			
			
			
			var trTag = '';
			$("#inbodyAndPtTable").empty();
			
			$.each(result, function(i){
				trTag += '<tr onClick=location.href="/trainer/inbodyReport?seq=' + result[i].inBodySeq + '" style="cursor:pointer;"><td>' + result[i].inBodySeq + '</td>';
				trTag += '<td>' + result[i].inBodyDate + " Inbody기록" + '</td>';
				trTag += '<td>' + result[i].lastDate + '</td></tr>';
			});
			$("#inbodyAndPtTable").append(trTag);
		},
		error: function (request,status,error) {
			   alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
			   console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		}
//		error: function (jqXHR, textStatus, errorThrown) {
//			   alert("오류가 발생하였습니다.");
//		}
	 });
});


$("#ptWriteBtn").click(function(){
	
	var count = $("#count").val();
	if(count == 0 || count < 0){
		alert('회원의 PT 이용 기간이 끝났습니다. 더이상 등록할 수 없습니다.');
		return false;
	}
	else{
		$("#ptForm").submit();
	}
});

