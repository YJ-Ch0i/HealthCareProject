$("#logoutTag").click(function(){
	$.ajax({
	 type: "post",
	 url: "/logout",
	 dataType:"json",
	 success: function(result){
		 alert(result.result);
		 location.href=result.link;
	},
	error: function (request,status,error) {
		   alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		   console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
	},
	error: function (jqXHR, textStatus, errorThrown) {
		   alert("오류가 발생하였습니다.");
	}
 });
});