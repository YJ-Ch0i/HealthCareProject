
$("#memberName").keyup(function(){
	
	var memberName = $("#memberName").val();
	
	$.ajax({
	 type: "post",
	 url: "/trainer/searchMember",
	 dataType:"json",
	 data:{memberName : memberName},		 
	 success: function(result){
		 console.log(result);
		 $("#memberChangeTable").empty();
		 var trTag = '';
		 $.each(result, function(i){
			trTag += '<tr><td>' + result[i].memberSeq + '</td>';
			trTag += '<td>' + result[i].memberName + '</td>';
			trTag += '<td>' + result[i].memberAge + '</td>';
			trTag += '<td>' + result[i].memberGender + '</td>';
			trTag += '<td>' + '<form id="memberDetailBoard" method="post" action="/trainer/memberDetailBoard" role="form">'
			trTag += '<input type="hidden" name="memberValue" value="' + result[i].memberSeq + '">'
			trTag += '<input type="submit" class="btn btn-mod btn-small" value="상세보기"></form></td></tr>';
		 })
		 $("#memberChangeTable").append(trTag);
	},
	error: function (request,status,error) {
		   alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		   console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
	},
	error: function (jqXHR, textStatus, errorThrown) {
		   alert("오류가 발생하였습니다.");
	}
  });
});