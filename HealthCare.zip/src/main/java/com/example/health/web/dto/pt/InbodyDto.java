package com.example.health.web.dto.pt;

import java.sql.Date;

public class InbodyDto {

	private int inBodySeq;
	private int memberSeq;
	private double weight;
	private double height;
	private double muscleMass;
	private double fatMass;
	private double bmi;
	private double bMetabolicRate;
	private int userSeq;
	private Date inBodyDate;
	private Date lastDate;
	
	public int getInBodySeq() {
		return inBodySeq;
	}
	public void setInBodySeq(int inBodySeq) {
		this.inBodySeq = inBodySeq;
	}
	public int getMemberSeq() {
		return memberSeq;
	}
	public void setMemberSeq(int memberSeq) {
		this.memberSeq = memberSeq;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getMuscleMass() {
		return muscleMass;
	}
	public void setMuscleMass(double muscleMass) {
		this.muscleMass = muscleMass;
	}
	public double getFatMass() {
		return fatMass;
	}
	public void setFatMass(double fatMass) {
		this.fatMass = fatMass;
	}
	public double getBmi() {
		return bmi;
	}
	public void setBmi(double bmi) {
		this.bmi = bmi;
	}
	public double getbMetabolicRate() {
		return bMetabolicRate;
	}
	public void setbMetabolicRate(double bMetabolicRate) {
		this.bMetabolicRate = bMetabolicRate;
	}
	public int getUserSeq() {
		return userSeq;
	}
	public void setUserSeq(int userSeq) {
		this.userSeq = userSeq;
	}
	public Date getInBodyDate() {
		return inBodyDate;
	}
	public void setInBodyDate(Date inBodyDate) {
		this.inBodyDate = inBodyDate;
	}
	public Date getLastDate() {
		return lastDate;
	}
	public void setLastDate(Date lastDate) {
		this.lastDate = lastDate;
	}
}
