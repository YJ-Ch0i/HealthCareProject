package com.example.health.web.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.health.common.CommonUtil;
import com.example.health.common.Constant;
import com.example.health.web.dto.pt.ExerciseType;
import com.example.health.web.dto.pt.InbodyDto;
import com.example.health.web.dto.pt.PTdetailDto;
import com.example.health.web.dto.pt.PersonalTrainingDto;
import com.example.health.web.dto.user.MemberDto;
import com.example.health.web.dto.user.TrainerDto;
import com.example.health.web.service.trainer.TrainerServiceImpl;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * Trainer Controller
 * @author yeong
 *
 */
@Controller
public class TrainerController {

	@Autowired
	private TrainerServiceImpl trainerService;

	@RequestMapping(value="/trainer/Login", method=RequestMethod.POST)	
	public @ResponseBody String trainerLogin(HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();
		JsonObject obj = new JsonObject();
		String json = "";
		TrainerDto dto = new TrainerDto();
		TrainerDto trainer = new TrainerDto();
		if(CommonUtil.isNotNullString(request.getParameter("adId")) &&
				CommonUtil.isNotNullString(request.getParameter("adPass"))) {
			
			dto.setUserId(request.getParameter("adId"));
			dto.setUserPw(request.getParameter("adPass"));
			
			trainer = trainerService.getTrainer(dto.getUserId());
			boolean isProcessing = trainerService.loginTrainer(dto.getUserId(), dto.getUserPw());
			
			if(isProcessing) {			
//				session.setAttribute("loginInfo", dto.getUserId());
				session.setAttribute("loginInfo", trainer);
				obj.addProperty("result", "/trainer/main");
				json = new Gson().toJson(obj);
			}
			else {
				obj.addProperty("result", false);
				json = new Gson().toJson(obj);
			}
		}
		else {
			obj.addProperty("result", false);
			json = new Gson().toJson(obj);
		}
		
		return json;
	}
	
	@RequestMapping(value="/trainer/main", method=RequestMethod.GET)
	public String trainerMain(HttpServletRequest request, Model model) throws Exception {
		HttpSession session = request.getSession();
//		String trainerSession = (String) session.getAttribute("loginInfo");
		TrainerDto trainerSession = (TrainerDto) session.getAttribute("loginInfo");
		session.setAttribute("loginInfo", trainerSession);
		
		if(trainerSession.getUserAuthSeq() == Constant.MANAGER) {
			model.addAttribute("memberList", trainerService.getAllMemberList());
		}
		else {
			model.addAttribute("memberList", trainerService.getMemberList(trainerSession));
		}
		return "user/trainer/trainerMain";
	}
	
	/**
	 * 회원 검색 Ajax용
	 * @param request
	 * @return
	 */
	//TODO
	@RequestMapping(value="/trainer/searchMember", method= {RequestMethod.POST, RequestMethod.GET})
	public @ResponseBody String searchMember(String memberName, Model model, HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();
		TrainerDto trainer = (TrainerDto) session.getAttribute("loginInfo");
		if(trainer.getUserAuthSeq() == Constant.MANAGER) {
			List<MemberDto> memberList = trainerService.searchMemberForAdmin(memberName);
			String json = new Gson().toJson(memberList);
			return json;
		}
		else {
			List<MemberDto> memberList = trainerService.searchMember(trainer.getUserSeq(), memberName);
			String json = new Gson().toJson(memberList);
			return json;
		}
	}
	
	@RequestMapping(value="/trainer/memberRegister", method=RequestMethod.POST)
	public @ResponseBody String registerMember(MemberDto dto, HttpServletRequest request) throws Exception {
		boolean isRegister = trainerService.registerMember(dto);
		JsonObject obj = new JsonObject();
		String json;
		if(isRegister) {
			obj.addProperty("result", "/trainer/main");
			json = new Gson().toJson(obj);
		}
		else {
			obj.addProperty("result", false);
			json = new Gson().toJson(obj);
		}
		return json;
	}
	
	@RequestMapping(value="/trainer/trainerRegist", method= {RequestMethod.POST, RequestMethod.GET})
	public @ResponseBody String registerTrainer(TrainerDto dto, HttpServletRequest reqest) throws Exception{
		boolean isRegister = trainerService.registerTrainer(dto);
		JsonObject obj = new JsonObject();
		String json;
		if(isRegister) {
			obj.addProperty("result", "/trainer/main");
			json = new Gson().toJson(obj);
		}
		else {
			obj.addProperty("result", false);
			json = new Gson().toJson(obj);
		}
		return json;
	}
	
	@RequestMapping(value="/trainer/memberInbodyRegister", method=RequestMethod.POST)
	public @ResponseBody String registerMemberInbodyData(InbodyDto dto, HttpServletRequest request) throws Exception {
		boolean isRegister = trainerService.registerMemberInbodyInfo(dto);
		JsonObject obj = new JsonObject();
		String json;
		
		if(isRegister) {
			obj.addProperty("result", "/trainer/memberDetailBoard?memberValue=" + dto.getMemberSeq());
			json = new Gson().toJson(obj);
		}
		else {
			obj.addProperty("result", false);
			json = new Gson().toJson(obj);
		}
		return json;
	}
	
	@RequestMapping(value="/trainer/memberPtRegister", method=RequestMethod.POST)
	public @ResponseBody String registerMemberPtData(PTdetailDto pt, HttpServletRequest request) throws Exception {
		
		boolean isRegister = trainerService.registerMemberPTInfo(pt);
		JsonObject obj = new JsonObject();
		String json;
		
		if(isRegister) {
			obj.addProperty("result", "/trainer/memberDetailBoard?memberValue=" + pt.getMemberSeq());
			json = new Gson().toJson(obj);
		}
		else {
			obj.addProperty("result", false);
			json = new Gson().toJson(obj);
		}
		return json;
	}
	
	@RequestMapping(value="/trainer/trainingReport", method= {RequestMethod.POST, RequestMethod.GET})
	public String trainingReportPage(int seq, Model model, HttpServletRequest request) throws Exception {
		HashMap<String, Object> map = trainerService.getTrainersReport(seq);
		
		PTdetailDto report = (PTdetailDto) map.get("report");
		List<ExerciseType> list = (List<ExerciseType>) map.get("list");
		JsonArray arr = (JsonArray) map.get("json");
		MemberDto member = trainerService.getMember(report.getMemberSeq());
		
		model.addAttribute("member", member);
		model.addAttribute("report", report);
		model.addAttribute("list", list);
		model.addAttribute("json", arr);
		
		return "user/trainer/memberReport/trainingReport";
	}
	
	@RequestMapping(value="/trainer/inbodyReport", method= {RequestMethod.POST, RequestMethod.GET})
	public String inbodyReportPage(int seq, Model model, HttpServletRequest request) throws Exception {
		Map<String, Object> map = trainerService.getInbodyReport(seq);
		InbodyDto inbody = (InbodyDto) map.get("inbody");
		MemberDto member = trainerService.getMember(inbody.getMemberSeq());
		String json = (String) map.get("json");
		model.addAttribute("member", member);
		model.addAttribute("inbody", inbody);
		model.addAttribute("report", json);		
		
		return "user/trainer/memberReport/inbodyReport";
	}
	
	@RequestMapping(value="/trainer/ptProgramRegister", method=RequestMethod.POST)
	public @ResponseBody String registerPrograms(PersonalTrainingDto dto, HttpServletRequest request) throws Exception {
		boolean isRegister = trainerService.ptProgramRegister(dto);
		JsonObject obj = new JsonObject();
		String json;
		
		if(isRegister) {
			obj.addProperty("result", "/trainer/main");
			json = new Gson().toJson(obj);
		}
		else {
			obj.addProperty("result", false);
			json = new Gson().toJson(obj);
		}
		return json;		
	}
	
	
}
