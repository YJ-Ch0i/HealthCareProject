package com.example.health.web.controller;

import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.health.web.dto.pt.PTpriceDto;
import com.example.health.web.dto.pt.PersonalTrainingDto;
import com.example.health.web.dto.user.TrainerDto;
import com.example.health.web.service.trainer.TrainerServiceImpl;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Controller
public class PageController {
	
	@Autowired
	private TrainerServiceImpl trService;

	/**
	 * 등록 시간을 알아내기 위함.
	 */
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	String date = format.format(System.currentTimeMillis());
	
	@RequestMapping(value="/main")
	public String index() throws Exception {
		return "index";
	}
	
	@RequestMapping(value="/memberMain")
	public String memberLogin() throws Exception {
		return "user/member/memberIndex";
	}
	
	@RequestMapping(value="/trainer/trainerRegister", method= {RequestMethod.GET, RequestMethod.POST})
	public String registAdmin(Model model) throws Exception {
		model.addAttribute("nowDate", date);
		
		return "user/trainer/trainerRegist";
	}
	
	@RequestMapping(value="/memberLogin")
	public String memberIndex() throws Exception {
		return "user/member/memberIndex";
	}
	
	@RequestMapping(value="/trainer/memberRegist", method= {RequestMethod.GET, RequestMethod.POST})
	public String registMember(Model model) throws Exception {
		List<PersonalTrainingDto> ptList = trService.getPTList();
		List<TrainerDto> trList = trService.getTrainerList();
		
		model.addAttribute("nowDate", date);
		model.addAttribute("ptList", ptList);
		model.addAttribute("trList", trList);
		
		return "user/trainer/memberRegist";
	}
	
	@RequestMapping(value="/trainer/programRegister", method= {RequestMethod.GET, RequestMethod.POST})
	public String registPrograms(Model model) throws Exception{
		List<PTpriceDto> priceList = trService.getProgramsPrice();
		
		model.addAttribute("nowDate", date);
		model.addAttribute("priceList", priceList);
		return "user/trainer/adPTRegister";
	}
	
	/**
	 * 로그아웃 및 세션초기화
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/logout")
	public @ResponseBody String logout(HttpServletRequest request) throws Exception {	
		HttpSession session = request.getSession();
		String json = "";
		if(session.getAttribute("loginInfo")!=null) {
			session.invalidate();		
			JsonObject obj = new JsonObject();		
			obj.addProperty("result", "로그아웃 되었습니다.");
			obj.addProperty("link", "/main");
			json = new Gson().toJson(obj);
		}
		else if(session.getAttribute("memberInfo") != null) {
			session.invalidate();		
			JsonObject obj = new JsonObject();
			obj.addProperty("link", "/memberMain");
			obj.addProperty("result", "로그아웃 되었습니다.");
			json = new Gson().toJson(obj);
		}
		return json;
	}
}
