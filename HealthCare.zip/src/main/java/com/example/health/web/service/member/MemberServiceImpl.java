package com.example.health.web.service.member;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.health.web.dao.member.MemberDao;
import com.example.health.web.dto.pt.ExerciseType;
import com.example.health.web.dto.pt.InbodyDto;
import com.example.health.web.dto.pt.PTdetailDto;
import com.example.health.web.dto.pt.PersonalTrainingDto;
import com.example.health.web.dto.user.MemberDto;
import com.example.health.web.dto.user.TrainerDto;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

/**
 * Member Service Implement
 * @author yeong
 *
 */
@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	MemberDao memberDao;

	@Override
	public MemberDto getMember(int memberSeq) throws Exception {
		return memberDao.getMember(memberSeq);
	}
	
	public List<PTdetailDto> getMembersRecord(MemberDto dto) throws Exception{
		return memberDao.getMembersRecord(dto);
	}
	
	public PersonalTrainingDto getMembersPt(MemberDto dto) throws Exception{
		return memberDao.getMembersPt(dto);
	}
	
	public List<InbodyDto> getMembersInbody(MemberDto dto) throws Exception{
		return memberDao.getMembersInbody(dto);
	}
	
	public MemberDto getMemberInfo(MemberDto dto) throws Exception{
		return memberDao.getMemberInfo(dto);
	}
	
	public boolean isMemberRegisterd(MemberDto dto) throws Exception{
		MemberDto member = memberDao.getMemberInfo(dto);
		if(member!=null) {
			return true;
		}
		return false;
	}
	
	public TrainerDto getMyTrainer(int userSeq) throws Exception {
		return memberDao.getTrainer(userSeq);
	}
	
	public Map<String, Object> getMemberPtRecord(PTdetailDto dto) throws Exception{
		
		PTdetailDto ptReport = memberDao.getMemberPtRecord(dto);
		
		Type listType = new TypeToken<List<ExerciseType>>(){}.getType();
		
		List<ExerciseType> list = new Gson().fromJson(ptReport.getTrainData(), listType);
		JsonArray arr = new JsonParser().parse(ptReport.getTrainData()).getAsJsonArray();
		
		Map<String, Object> map = new HashMap<>();
		map.put("report", ptReport);
		map.put("list", list);
		map.put("json", arr);
		
		return map;
	}
	
	public Map<String, Object> getMemberInbodyRecord(InbodyDto dto) throws Exception{
		InbodyDto inbody = memberDao.getMemberInbodyRecord(dto);
		String json = new Gson().toJson(inbody);
		
		Map<String, Object> map = new HashMap<>();
		map.put("json", json);
		map.put("inbody", inbody);
		return map;
	}
}
