package com.example.health.web.dto.pt;

import java.sql.Date;

/**
 * 회원별 PT 테이블
 * @author yeong
 *
 */
public class PTdetailDto {

	private int psTrainDetailSeq;
	private Date psTrainDate;
	private int memberSeq;
	private String trainData;
	private String remark;
	private int userSeq;
	private Date lastDate;
	
	public int getPsTrainDetailSeq() {
		return psTrainDetailSeq;
	}
	public void setPsTrainDetailSeq(int psTrainDetailSeq) {
		this.psTrainDetailSeq = psTrainDetailSeq;
	}
	public Date getPsTrainDate() {
		return psTrainDate;
	}
	public void setPsTrainDate(Date psTrainDate) {
		this.psTrainDate = psTrainDate;
	}
	public int getMemberSeq() {
		return memberSeq;
	}
	public void setMemberSeq(int memberSeq) {
		this.memberSeq = memberSeq;
	}
	public String getTrainData() {
		return trainData;
	}
	public void setTrainData(String trainData) {
		this.trainData = trainData;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public int getUserSeq() {
		return userSeq;
	}
	public void setUserSeq(int userSeq) {
		this.userSeq = userSeq;
	}
	public Date getLastDate() {
		return lastDate;
	}
	public void setLastDate(Date lastDate) {
		this.lastDate = lastDate;
	}
}
