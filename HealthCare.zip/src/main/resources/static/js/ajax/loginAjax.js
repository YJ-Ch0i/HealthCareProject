
//관리자 및 트레이너 로그인
$("#logBtn").click(function(){
	var id = $("#adId").val();
	var pass = $("#adPass").val();
	
	console.log("ajax 진입")

	$.ajax({
	 type: "post",
	 url: "/trainer/Login",
	 dataType:"json",
	 data:{adId : id,
		 adPass : pass},
	 success: function(result){
		 console.log(result.result);
		 if(result.result == false){
			 
			 $("#adId").val('');
			 $("#adPass").val('');
			 
			 alert("로그인에 실패하였습니다. 계정과 비밀번호를 확인 해 주세요.");
			 $("#adId").focus();
		 }
		 else{
			 location.href="/trainer/main";
		 }
	},
	error: function (request,status,error) {
		   alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		   console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
	},
	error: function (jqXHR, textStatus, errorThrown) {
		   alert("오류가 발생하였습니다.");
	}
 });
});


//회원 로그인
$("#memLoginBtn").click(function(){
	var id = $("#memberName").val();
	var pass = $("#memberPhone").val();
	
	//빈값체크
	if(id == ""){
		alert("이름을 입력 해 주세요");
		$("#memberName").focus();
		return false;
	}
	if(pass == ""){
		alert("휴대폰 번호를 입력 해 주세요");
		$("#memberPhone").focus();
		return false;
	}
	
	console.log("ajax 진입")

	$.ajax({
	 type: "post",
	 url: "/member/Login",
	 dataType:"json",
	 data:{memberName : id,
		 memberPhone : pass},
	 success: function(result){
		 console.log(result.result);
		 if(result.result == false){
			 $("#memberName").val('');
			 $("#memberPhone").val('');
			 
			 alert("회원정보가 맞지 않거나 존재하지 않습니다. 이름과 휴대폰 번호를 확인 해 주세요.");
			 $("#adId").focus();
		 }
		 else{
			 location.href=result.result;
		 }
	},
	error: function (request,status,error) {
		   alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		   console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
	},
	error: function (jqXHR, textStatus, errorThrown) {
		   alert("오류가 발생하였습니다.");
	}
 });
});