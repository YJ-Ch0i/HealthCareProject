package com.example.health.web.service.trainer;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.health.common.CommonUtil;
import com.example.health.web.dao.trainer.TrainerDao;
import com.example.health.web.dto.pt.ExerciseType;
import com.example.health.web.dto.pt.InbodyDto;
import com.example.health.web.dto.pt.PTdetailDto;
import com.example.health.web.dto.pt.PTpriceDto;
import com.example.health.web.dto.pt.PersonalTrainingDto;
import com.example.health.web.dto.user.MemberDto;
import com.example.health.web.dto.user.TrainerDto;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

/**
 * Trainer Service Class
 * @author yeong
 */
@Service
public class TrainerServiceImpl implements TrainerService {
	
	private SqlSession sqlSession;
	public SqlSession getSqlSession(){
		return sqlSession;
	}
	
	@Autowired
	TrainerDao trDao;
		
	/**
	 * Trainer 객체 리턴
	 */
	@Override
	public TrainerDto getTrainer(String adId) throws Exception {		
		TrainerDto trainer = trDao.getTrainer(adId);
		return trainer;
	}
	
	@Override
	public List<TrainerDto> getTrainerList() throws Exception{
		return trDao.getTrainerList();
	}

	/**
	 * Trainer Longin
	 */
	@Override
	public boolean loginTrainer(String id, String pass) throws Exception {
		
		TrainerDto trainer = getTrainer(id);

		if(CommonUtil.isNotNullString(id) && CommonUtil.isNotNullString(pass)) {
			if(CommonUtil.isEqualString(trainer.getUserPw(), pass)) {
				return true;
			}
		}
		else if(trainer.getUserId() == null) {
			return false;
		}
		return false;
	}
	
	public boolean registerMember(MemberDto dto) throws Exception{
		int isRegister = trDao.registerMember(dto);
		
		if(isRegister == 1) {
			return true;
		}
		else return false;
	}
	
	public boolean registerTrainer(TrainerDto dto) throws Exception{
		int isRegister = trDao.registerTrainer(dto);
		
		if(isRegister == 1) {
			return true;
		}
		else return false;
	}
	
	public MemberDto getMember(int memberSeq) throws Exception{
		return trDao.getMember(memberSeq);
	}

	public List<MemberDto> getAllMemberList() throws Exception{
		return trDao.getAllMemberList();
	}
	
	public List<MemberDto> getMemberList(TrainerDto dto) throws Exception{
		return trDao.getMemberList(dto);
	}
	
	public List<PersonalTrainingDto> getPTList() throws Exception{
		List<PersonalTrainingDto> ptList = new ArrayList<>();
		ptList = trDao.getPTList();
		return ptList;
	}
	
	public boolean registerMemberInbodyInfo(InbodyDto dto) throws Exception{
		int isRegist = trDao.registerMemberInbodyInfo(dto);
		
		if(isRegist == 1) {
			return true;
		}
		else return false;
	}
	
	public boolean registerMemberPTInfo(PTdetailDto dto) throws Exception{
		int isRegist = trDao.registerMemberPtInfo(dto);
		
		if(isRegist == 1) {
			return true;
		}
		else return false;
	}
	
	public HashMap<String, Object> getTrainersReport(int seq) throws Exception {
		PTdetailDto report = trDao.getPtDetail(seq);
		
		Gson gson = new Gson();
		Type listType = new TypeToken<List<ExerciseType>>(){}.getType();
		
		List<ExerciseType> list = gson.fromJson(report.getTrainData(), listType);				
		JsonArray arr = new JsonParser().parse(report.getTrainData()).getAsJsonArray();
		
		HashMap<String, Object> map = new HashMap<>();
		map.put("report", report);
		map.put("list", list);
		map.put("json", arr);
		
		return map;
	}
	
	public Map<String, Object> getInbodyReport(int seq) throws Exception {		
		InbodyDto inbody = trDao.getInbody(seq);
		String json = new Gson().toJson(inbody);
		
		Map<String, Object> map = new HashMap<>();
		map.put("json", json);
		map.put("inbody", inbody);
		return map;
	}
	
	public List<PTpriceDto> getProgramsPrice() throws Exception{
		return trDao.getPtPrices();
	}
	
	public boolean ptProgramRegister(PersonalTrainingDto dto) throws Exception{
		return trDao.registerPtPrograms(dto);
	}
	
	/**
	 * 회원이름검색을 비동기로 조회하는 메소드
	 * @param name
	 */
	public List<MemberDto> searchMember(int userSeq, String memberName) throws Exception {
		return trDao.getMemberListForSearch(userSeq, memberName);
	}
	
	/**
	 * 관리자용 회원이름검색을 비동기로 조회하는 메소드
	 * @param name
	 */
	public List<MemberDto> searchMemberForAdmin(String memberName) throws Exception {
		return trDao.getMemberListForAdmin(memberName);
	}
}
